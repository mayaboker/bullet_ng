# Lesson 6.1 — Visualizing CNN Training with PyTorch Dashboards

**Course:** Visual Neural Networks · **Prerequisite:** Lessons 1–6 · **Dataset:** MNIST  
**Goal:** Watch a CNN learn, recognize overfitting, compare experiments, and save the best checkpoint.

> **About the figures:** The three training plots below use *illustrative synthetic values*, not actual MNIST measurements. Run the included Python script to generate your own real training curves in TensorBoard.

## 1. Which dashboard should I choose?

| Tool | Live training curves | Experiment comparison | Deployment | Best use |
|---|---|---|---|---|
| **TensorBoard** | Yes | Yes | Local | Easiest start with PyTorch |
| **ClearML** | Yes | Yes | Cloud or self-hosted | Full experiment tracking and artifacts |
| **MLflow** | Yes | Yes | Local or hosted | Tracking models, metrics, and runs |
| **Weights & Biases** | Yes | Yes | Primarily hosted | Team collaboration and tracking |
| **Matplotlib** | Not automatically | Write code | Local | Reports and custom plots |

**Recommendation for this course:** Start with **TensorBoard**. Later, use ClearML or MLflow if you need reproducible, organized experiment management.

## 2. Install and start TensorBoard

```bash
pip install torch torchvision tensorboard
python train_mnist_tensorboard.py
tensorboard --logdir runs
```

Then open **http://localhost:6006** in your browser. If the training runs on a remote machine, forward port 6006 over SSH instead of exposing the dashboard publicly.

The included program creates a run in `runs/mnist_lr_0p001/`. TensorBoard reads its event files and updates plots as the program logs metrics.

## 3. What should we graph?

| Metric | X-axis | Y-axis | Why it matters |
|---|---|---|---|
| Train loss / validation loss | Epoch | Cross-entropy loss | Detect overfitting and choose a checkpoint |
| Train accuracy / validation accuracy | Epoch | Accuracy (%) | Compare learning with generalization |
| Learning rate | Epoch | Optimizer learning rate | Check learning-rate settings and schedules |
| Weight histograms | Epoch | Weight values and their frequencies | See how weight distributions change |

### Graph A — Training and validation loss

![Illustrative training and validation loss](assets/loss_curves.svg)

The lowest **validation loss** occurs near epoch 7. Later, training loss keeps falling while validation loss rises: a typical **overfitting signal**. Save the checkpoint at the best validation epoch rather than automatically keeping the final epoch.

### Graph B — Training and validation accuracy

![Illustrative training and validation accuracy](assets/accuracy_curves.svg)

Training accuracy may continue rising while validation accuracy levels off. Accuracy and loss are complementary: loss detects confidence changes even when the predicted class stays the same.

### Graph C — Learning-rate experiments

![Illustrative learning-rate curves](assets/learning_rates.svg)

In this fictional example, `0.001` improves quickly, `0.0001` improves slowly, and `0.01` fluctuates. Real behavior depends on the model, optimizer, data, and training setup; a higher learning rate is not *always* worse.

## 4. The basic TensorBoard API

```python
from torch.utils.tensorboard import SummaryWriter
writer = SummaryWriter('runs/mnist_experiment_1')
writer.add_scalar('Loss/Train', 0.35, global_step=1)
writer.add_scalar('Loss/Validation', 0.40, global_step=1)
writer.add_scalar('Accuracy/Validation', 95.2, global_step=1)
writer.close()
```

A scalar is a single numeric measurement recorded at a particular training step or epoch. Consistent tags and steps make plots comparable.

## 5. Complete runnable example

The ZIP includes **`train_mnist_tensorboard.py`**, which:

1. Loads MNIST and divides the original 60,000 training images into **50,000 training** and **10,000 validation** images. It does **not** use the official 10,000-image test set during model selection.
2. Defines the same two-convolution CNN used in Lessons 3–5.
3. Trains for 20 epochs with Adam and cross-entropy loss.
4. Logs train/validation loss, train/validation accuracy, and learning rate.
5. Logs an image grid and occasional convolutional weight histograms.
6. Saves `checkpoints/best_mnist.pth` whenever the **validation loss** improves.

For clarity, the training loop is provided as a separate executable Python file instead of being duplicated here. The most important logging lines are:

```python
writer.add_scalar('Loss/Train', train_loss, epoch)
writer.add_scalar('Loss/Validation', val_loss, epoch)
writer.add_scalar('Accuracy/Train', train_acc, epoch)
writer.add_scalar('Accuracy/Validation', val_acc, epoch)
writer.add_scalar('Learning_rate', optimizer.param_groups[0]['lr'], epoch)
```

For a weight histogram:

```python
writer.add_histogram('Weights/conv1', model.conv1.weight.detach(), epoch)
```

For a sample grid of MNIST images:

```python
from torchvision.utils import make_grid
writer.add_image('MNIST/Examples', make_grid(images[:16], nrow=4), epoch)
```

## 6. Compare experiments

Use a **different run directory** for each configuration, for example:

```text
runs/
├── mnist_lr_0p0001/
├── mnist_lr_0p001/
└── mnist_lr_0p01/
```

Change the optimizer's learning rate and the run directory together for each experiment. Restart from a **newly initialized model** each time. To make comparisons fair, keep the data split, architecture, seed, epochs, and batch size the same.

In TensorBoard, select the runs you want to compare. Inspect both final results and curve shape—not just the training accuracy.

## 7. How the workflow fits together

![Experiment-driven CNN workflow](assets/workflow.svg)

A dashboard does not improve the model by itself. It helps you decide what to change, test that change fairly, and keep the best-performing model.

## 8. Practical exercise

1. Run the provided script and open TensorBoard.
2. Find the epoch with the lowest validation loss. Did validation accuracy peak at the same epoch?
3. Try learning rates `0.0001`, `0.001`, and `0.01` as independent runs.
4. Compare training loss, validation loss, and validation accuracy across the runs.
5. Open the **Images** and **Histograms** panels to inspect logged visualizations.
6. Load `checkpoints/best_mnist.pth` and evaluate it on the untouched official MNIST test set.

## 9. Common mistakes

- **Logging only training accuracy:** you may miss overfitting.
- **Using the test set to tune hyperparameters:** it compromises the final unbiased evaluation.
- **Applying data augmentation to validation images:** evaluation should be stable and representative.
- **Calling `softmax` before `CrossEntropyLoss`:** pass the model's raw logits directly.
- **Comparing runs with different splits or random seeds without recording them:** the comparison becomes harder to interpret.
- **Using raw `loss.item()` averages across variable batch sizes:** weight each batch's loss by its sample count, as the included script does.

## 10. Takeaways

**Train loss** answers, “Is the optimizer fitting the examples?”  
**Validation loss** answers, “Is the model generalizing to held-out examples?”  
**TensorBoard** makes these patterns visible during training.  
**Experiment tracking** gives you evidence for what to try next.

**Next:** Lesson 7 — From MNIST to CIFAR-10.

## References

- PyTorch TensorBoard tutorial: https://docs.pytorch.org/tutorials/recipes/recipes/tensorboard_with_pytorch.html
- PyTorch SummaryWriter reference: https://docs.pytorch.org/docs/stable/tensorboard.html
- ClearML PyTorch integration: https://clear.ml/docs/latest/docs/integrations/pytorch/

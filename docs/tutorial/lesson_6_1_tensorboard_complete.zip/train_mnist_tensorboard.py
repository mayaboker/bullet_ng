# train_mnist_tensorboard.py
# Requires: pip install torch torchvision tensorboard
# Run: python train_mnist_tensorboard.py
# Then: tensorboard --logdir runs
from pathlib import Path
import torch
from torch import nn
from torch.utils.data import DataLoader, random_split
from torchvision import datasets, transforms
from torchvision.utils import make_grid
from torch.utils.tensorboard import SummaryWriter

class SimpleCNN(nn.Module):
    def __init__(self):
        super().__init__()
        self.conv1 = nn.Conv2d(1, 16, kernel_size=3, padding=1)
        self.conv2 = nn.Conv2d(16, 32, kernel_size=3, padding=1)
        self.relu = nn.ReLU()
        self.pool = nn.MaxPool2d(2)
        self.flatten = nn.Flatten()
        self.fc = nn.Linear(32 * 7 * 7, 10)

    def forward(self, x):
        x = self.pool(self.relu(self.conv1(x)))
        x = self.pool(self.relu(self.conv2(x)))
        return self.fc(self.flatten(x))  # logits, not probabilities


def evaluate(model, loader, criterion, device):
    model.eval()
    loss_sum, correct, count = 0.0, 0, 0
    with torch.no_grad():
        for images, labels in loader:
            images, labels = images.to(device), labels.to(device)
            logits = model(images)
            loss = criterion(logits, labels)
            n = labels.size(0)
            loss_sum += loss.item() * n
            correct += (logits.argmax(1) == labels).sum().item()
            count += n
    return loss_sum / count, 100.0 * correct / count


def main():
    torch.manual_seed(42)
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    full_train = datasets.MNIST('./data', train=True, download=True,
                                transform=transforms.ToTensor())
    train_ds, val_ds = random_split(full_train, [50000, 10000],
                                    generator=torch.Generator().manual_seed(42))
    train_loader = DataLoader(train_ds, batch_size=64, shuffle=True)
    val_loader = DataLoader(val_ds, batch_size=64)
    model = SimpleCNN().to(device)
    optimizer = torch.optim.Adam(model.parameters(), lr=0.001)
    criterion = nn.CrossEntropyLoss()
    run_dir = 'runs/mnist_lr_0p001'
    writer = SummaryWriter(run_dir)
    Path('checkpoints').mkdir(exist_ok=True)

    # Only display examples from the validation split; no labels are used for training.
    examples, _ = next(iter(val_loader))
    writer.add_image('MNIST/Validation examples',
                     make_grid(examples[:16], nrow=4, normalize=True), 0)
    best_val_loss = float('inf')

    for epoch in range(1, 21):
        model.train()
        train_loss_sum, train_correct, train_count = 0.0, 0, 0
        for images, labels in train_loader:
            images, labels = images.to(device), labels.to(device)
            optimizer.zero_grad()
            logits = model(images)
            loss = criterion(logits, labels)
            loss.backward()
            optimizer.step()
            n = labels.size(0)
            train_loss_sum += loss.item() * n
            train_correct += (logits.argmax(1) == labels).sum().item()
            train_count += n

        train_loss = train_loss_sum / train_count
        train_acc = 100.0 * train_correct / train_count
        val_loss, val_acc = evaluate(model, val_loader, criterion, device)
        # Use separate scalar tags with the same category name for easy overlays.
        writer.add_scalar('Loss/Train', train_loss, epoch)
        writer.add_scalar('Loss/Validation', val_loss, epoch)
        writer.add_scalar('Accuracy/Train', train_acc, epoch)
        writer.add_scalar('Accuracy/Validation', val_acc, epoch)
        writer.add_scalar('Learning_rate', optimizer.param_groups[0]['lr'], epoch)

        # Histograms are optional: log them every 5 epochs to reduce overhead.
        if epoch % 5 == 0:
            writer.add_histogram('Weights/conv1', model.conv1.weight.detach(), epoch)
            writer.add_histogram('Weights/conv2', model.conv2.weight.detach(), epoch)

        if val_loss < best_val_loss:
            best_val_loss = val_loss
            torch.save(model.state_dict(), 'checkpoints/best_mnist.pth')
        print(f'Epoch {epoch:02d}: train loss={train_loss:.4f}, '
              f'val loss={val_loss:.4f}, train acc={train_acc:.2f}%, '
              f'val acc={val_acc:.2f}%')
        writer.flush()
    writer.close()


if __name__ == '__main__':
    main()

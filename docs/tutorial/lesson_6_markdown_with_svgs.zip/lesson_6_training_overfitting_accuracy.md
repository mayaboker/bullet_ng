# Lesson 6 — Training, Overfitting, and Improving Accuracy

**Course:** Visual Neural Networks | **Stage:** 1 — CNN Fundamentals | **Dataset:** MNIST  
**Prerequisites:** Lessons 1–5 | **Level:** Beginner | **Math:** Minimal

## Learning goals

After this lesson, you should be able to explain the difference between training, validation, and test data; recognize underfitting and overfitting from graphs; understand learning rate, epoch count, and batch size; and use simple data augmentation and early stopping to improve generalization.

> **A central idea:** A model that is excellent at the images it trained on is not necessarily good at images it has never seen.

## 1. Training is not the same as generalization

Our CNN learns by repeatedly viewing labeled MNIST digits and adjusting weights to reduce classification error. The real goal, however, is to classify **new** handwritten digits. We therefore evaluate it on data that wasn't used to update the weights.

![Dataset split diagram](lesson6_assets/data_splits.svg)

| Data split | Used for | Can its labels influence model selection? |
|---|---|---|
| **Training** | Compute loss, gradients, and weight updates | Yes — directly |
| **Validation** | Check learning progress, choose learning rate/epochs, select checkpoint | Yes — indirectly |
| **Test** | Final evaluation after decisions are made | Ideally **no** |

MNIST normally provides **60,000 training images** and **10,000 test images**. In this lesson we'll reserve **10,000 of the original training images** for validation and use the remaining **50,000 for training**. The official test set remains untouched until final evaluation.

**Why not use the test set every epoch?** Because repeated tuning based on test results makes that set part of your design process. It stops being a clean, independent measure of generalization.

## 2. Reading training and validation curves

At the end of every epoch we can compute:

- **Training loss:** How wrong the model is on examples used to learn.
- **Validation loss:** How wrong the model is on held-out examples.
- **Accuracy:** Percentage of images whose predicted digit matches the label.

![Underfitting, good fit, overfitting](lesson6_assets/training_patterns.svg)

**The curves above are synthetic teaching examples, not recorded MNIST experiment results.**

### A. Underfitting

Training and validation loss stay high. The network has not learned enough. Possible causes: too few epochs, an unsuitable learning rate, or an overly limited model.

### B. Good generalization

Training and validation loss both decrease and remain fairly close. The model is learning patterns that transfer to new images.

### C. Overfitting

Training loss keeps decreasing while validation loss starts increasing. The model is improving on training examples but getting worse, by this metric, on held-out examples.

**Important nuance:** Validation loss can rise even while validation accuracy stays flat or improves slightly. Loss cares about prediction confidence, not just whether the top-ranked class is correct.

### Understanding the “generalization gap”

Suppose your CNN achieves **99.8% training accuracy** and **97.0% validation accuracy**. The gap is **2.8 percentage points**. A noticeable gap can be a warning, but you should also inspect actual loss trends, dataset difficulty, and sample sizes rather than using one universal cutoff.

## 3. Learning rate: How large should each update be?

The optimizer uses gradients to decide how to change the CNN's weights. The **learning rate** controls the scale of these updates.

![Effect of learning rate](lesson6_assets/learning_rate.svg)

Again, these are **illustrative synthetic curves**.

| Learning rate | Intuition | Typical symptom |
|---|---|---|
| Too small | Take tiny steps | Learning is very slow |
| Reasonable | Take useful steps | Loss decreases steadily |
| Too large | Overshoot useful solutions | Loss oscillates, diverges, or becomes unstable |

For this small CNN, `Adam(lr=0.001)` is a sensible starting point, **not a universal optimal value**. Try `0.0001`, `0.001`, and `0.01` and compare validation results. Use the same architecture and data split for a meaningful comparison.

## 4. Epochs and batch size

- An **epoch** is one pass through the training dataset.
- A **batch** is a small group of images processed together.
- One **optimizer step** occurs after the gradients for a batch have been computed.

For 50,000 training images and a batch size of 64, one epoch contains **782 batches** (781 full batches and one smaller final batch), unless `drop_last=True`.

| Setting | Trade-off |
|---|---|
| More epochs | More opportunity to learn, but greater overfitting risk |
| Larger batches | Fewer optimizer steps per epoch; usually higher memory use |
| Smaller batches | More frequent weight updates; noisier gradient estimates |

Batch size doesn't have a single best value. For this lesson, **64** is a good practical starting point.

## 5. Data augmentation: Create helpful variation

Imagine the digit **7** drawn slightly to the left or rotated by a few degrees. It is still a 7. Augmentation applies small, label-preserving variations to training images so the model learns less brittle representations.

![Conceptual augmentation variants](lesson6_assets/augmentation.svg)

For MNIST, subtle translations, rotations, and scale changes can help. Very strong transformations can change the meaning of a digit (for example, some rotations make digits ambiguous). **Apply augmentation only to the training set**, not the validation or test set.

```python
from torchvision import transforms

train_transform = transforms.Compose([
    transforms.RandomAffine(
        degrees=10,
        translate=(0.08, 0.08),
        scale=(0.95, 1.05),
    ),
    transforms.ToTensor(),
])

eval_transform = transforms.ToTensor()
```

The label is unchanged. `RandomAffine` changes only the image, and `ToTensor` converts it to `[1, 28, 28]` with values scaled to `[0, 1]`.

## 6. Implement a clean train/validation/test split

Use the `SimpleCNN` definition from Lesson 4. The code below creates **separate dataset objects** for training and validation, so we can safely apply augmentation only to training images.

```python
import torch
from torch.utils.data import DataLoader, Subset
from torchvision import datasets, transforms

seed = 42
rng = torch.Generator().manual_seed(seed)
indices = torch.randperm(60_000, generator=rng).tolist()
train_indices = indices[:50_000]
val_indices = indices[50_000:]

train_transform = transforms.Compose([
    transforms.RandomAffine(degrees=10, translate=(0.08, 0.08)),
    transforms.ToTensor(),
])
eval_transform = transforms.ToTensor()

train_full = datasets.MNIST('./data', train=True, download=True,
                           transform=train_transform)
val_full = datasets.MNIST('./data', train=True, download=True,
                         transform=eval_transform)
test_dataset = datasets.MNIST('./data', train=False, download=True,
                             transform=eval_transform)

train_loader = DataLoader(Subset(train_full, train_indices),
                          batch_size=64, shuffle=True)
val_loader = DataLoader(Subset(val_full, val_indices),
                        batch_size=64, shuffle=False)
test_loader = DataLoader(test_dataset, batch_size=64, shuffle=False)
```

This split is reproducible from the fixed index seed. Different PyTorch runs may still vary slightly due to initialization, data-loader randomness, and GPU operations.

## 7. Log both loss and accuracy

We need to evaluate the network after each epoch. A key detail: **`model.eval()` does not disable gradients by itself**, so we also use `torch.no_grad()` for evaluation.

```python
import torch.nn as nn

def evaluate(model, loader, criterion, device):
    model.eval()
    total_loss = 0.0
    correct = 0
    count = 0

    with torch.no_grad():
        for images, labels in loader:
            images = images.to(device)
            labels = labels.to(device)
            logits = model(images)
            loss = criterion(logits, labels)

            batch_size = labels.size(0)
            total_loss += loss.item() * batch_size
            correct += (logits.argmax(dim=1) == labels).sum().item()
            count += batch_size

    return total_loss / count, correct / count
```

Notice we multiply the batch's mean loss by its size before aggregating. This keeps the reported average correct even when the final batch is smaller.

## 8. Train and keep the best validation checkpoint

```python
import torch

# Reuse the SimpleCNN class from Lesson 4.
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
model = SimpleCNN().to(device)
criterion = nn.CrossEntropyLoss()
optimizer = torch.optim.Adam(model.parameters(), lr=0.001)

history = {'train_loss': [], 'train_acc': [],
           'val_loss': [], 'val_acc': []}
best_val_loss = float('inf')
patience = 3
bad_epochs = 0

for epoch in range(20):
    model.train()
    loss_sum = 0.0
    correct = 0
    total = 0

    for images, labels in train_loader:
        images, labels = images.to(device), labels.to(device)
        optimizer.zero_grad()
        logits = model(images)
        loss = criterion(logits, labels)
        loss.backward()
        optimizer.step()

        n = labels.size(0)
        loss_sum += loss.item() * n
        correct += (logits.argmax(1) == labels).sum().item()
        total += n

    train_loss, train_acc = loss_sum / total, correct / total
    val_loss, val_acc = evaluate(model, val_loader, criterion, device)

    for key, value in [('train_loss', train_loss),
                       ('train_acc', train_acc),
                       ('val_loss', val_loss),
                       ('val_acc', val_acc)]:
        history[key].append(value)

    print(f'Epoch {epoch+1:02d}  '
          f'train loss={train_loss:.3f} acc={train_acc:.1%}  '
          f'val loss={val_loss:.3f} acc={val_acc:.1%}')

    if val_loss < best_val_loss:
        best_val_loss = val_loss
        torch.save(model.state_dict(), 'best_mnist_cnn.pth')
        bad_epochs = 0
    else:
        bad_epochs += 1
        if bad_epochs >= patience:
            print('Early stopping: validation loss stopped improving.')
            break

model.load_state_dict(torch.load('best_mnist_cnn.pth',
                                  map_location=device,
                                  weights_only=True))
test_loss, test_acc = evaluate(model, test_loader, criterion, device)
print(f'Final test accuracy: {test_acc:.2%}; loss: {test_loss:.3f}')
```

**Early stopping** monitors validation loss and stops training after three consecutive epochs without a new best. The checkpoint is selected based on **validation loss**, never test performance. Note that early stopping is a heuristic; a noisy validation curve may improve again later.

**A subtle point about training metrics:** Our training images are augmented, but validation images are not. That makes training and validation loss less directly comparable. For a strict like-for-like gap, also evaluate a **nonaugmented training subset** in `eval()` mode.

## 9. Plot your *real* learning curves

Unlike the earlier illustrative SVGs, this code plots your actual recorded training run:

```python
import matplotlib.pyplot as plt

epochs = range(1, len(history['train_loss']) + 1)

plt.figure(figsize=(8, 4))
plt.plot(epochs, history['train_loss'], label='Training loss')
plt.plot(epochs, history['val_loss'], label='Validation loss')
plt.xlabel('Epoch')
plt.ylabel('Cross-entropy loss')
plt.title('MNIST — training vs. validation')
plt.legend()
plt.grid(alpha=0.2)
plt.tight_layout()
plt.savefig('my_training_curves.svg')
plt.show()
```

If validation loss begins rising persistently while training loss falls, inspect overfitting. If both remain high, investigate underfitting. If training is unstable, investigate learning rate. Do not decide solely from one epoch's fluctuation.

## 10. A simple experiment

Train the same architecture three times and record the **best validation accuracy**, **best validation loss**, and **epoch at which the best checkpoint occurred**.

| Run | Change | Hypothesis to test |
|---|---|---|
| A | No augmentation, `lr=0.001` | Baseline |
| B | Mild augmentation, `lr=0.001` | Does validation performance improve? |
| C | Mild augmentation, `lr=0.01` | Does a larger learning rate become unstable or learn differently? |

To make a fair comparison, keep the split and architecture fixed. Prefer multiple random seeds if differences are small. **Do not assume augmentation always improves MNIST accuracy**; the outcome is empirical.

## 11. Common mistakes

- **Tuning on the test set:** makes final reported accuracy overly optimistic.
- **Applying augmentation to validation/test:** makes evaluation inconsistent or unnecessarily difficult.
- **Comparing train and validation loss carelessly:** training-mode augmentation and dropout may change the meaning of the comparison.
- **Using `softmax` before `CrossEntropyLoss`:** pass raw logits; cross-entropy handles log-softmax internally.
- **Forgetting `model.eval()`:** dropout and batch normalization behave differently in evaluation mode.
- **Using only accuracy:** inspect loss as well; confidence and calibration can change even when accuracy does not.

## 12. Quick knowledge check

**Q1.** Training accuracy is 99.9%, but validation accuracy is 93%. What should you investigate?  
**Answer:** Possible overfitting, a distribution mismatch, and differences in data processing.

**Q2.** Why not select a checkpoint using the test set?  
**Answer:** It would influence model selection, so the test set would no longer represent an independent final evaluation.

**Q3.** What does a learning rate that is too high often look like?  
**Answer:** Oscillating or diverging training loss, rather than reliable convergence.

**Q4.** Does training for more epochs always improve validation accuracy?  
**Answer:** No; improvement can plateau or reverse if the model overfits.

## Summary — Stage 1 complete

You've now learned how pixels become feature maps, how filters and classifier weights are trained, and how to judge whether the network generalizes beyond its training data.

**Next: Lesson 7 — From MNIST to CIFAR-10.** We'll move from one-channel 28 × 28 handwritten digits to three-channel 32 × 32 color images of everyday objects. This will show why recognizing natural images is harder and why deeper feature extractors become useful.

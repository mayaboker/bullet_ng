import torch
from torch import nn


class LabCNN(nn.Module):
    def __init__(self, optimized: bool = False):
        super().__init__()
        self.stem = nn.Sequential(
            nn.Conv2d(3, 32, kernel_size=3, stride=2, padding=1),
            nn.ReLU(),
        )
        if optimized:
            self.feature = nn.Sequential(
                nn.Conv2d(32, 32, kernel_size=3, padding=1,
                          groups=32, bias=False),
                nn.Conv2d(32, 64, kernel_size=1),
            )
        else:
            self.feature = nn.Conv2d(32, 64, kernel_size=3, padding=1)
        self.activation = nn.ReLU()
        self.pool = nn.AdaptiveAvgPool2d(1)
        self.classifier = nn.Linear(64, 10)

    def forward(self, x):
        x = self.stem(x)
        x = self.activation(self.feature(x))
        x = self.pool(x)
        x = torch.flatten(x, 1)
        return self.classifier(x)


def export(model: nn.Module, filename: str):
    model.eval()
    sample = torch.randn(1, 3, 224, 224)
    with torch.no_grad():
        output = model(sample)
    assert tuple(output.shape) == (1, 10)
    torch.onnx.export(
        model, (sample,), filename,
        input_names=['input'], output_names=['logits'],
        opset_version=17, dynamo=False,
    )


if __name__ == '__main__':
    torch.manual_seed(42)
    for name, optimized in [('original', False), ('optimized', True)]:
        model = LabCNN(optimized=optimized)
        export(model, f'{name}.onnx')
        n_params = sum(p.numel() for p in model.parameters())
        print(f'{name:10} parameters={n_params:,}  output=(1, 10)')

from time import perf_counter
import numpy as np
import onnxruntime as ort


def benchmark(model_path: str) -> float:
    opts = ort.SessionOptions()
    opts.intra_op_num_threads = 1
    session = ort.InferenceSession(
        model_path, sess_options=opts,
        providers=['CPUExecutionProvider'],
    )
    name = session.get_inputs()[0].name
    x = np.random.default_rng(42).normal(size=(1, 3, 224, 224)).astype('float32')
    for _ in range(20):
        session.run(None, {name: x})
    measurements = []
    for _ in range(100):
        start = perf_counter()
        session.run(None, {name: x})
        measurements.append((perf_counter() - start) * 1000)
    return float(np.median(measurements))


if __name__ == '__main__':
    a = benchmark('original.onnx')
    b = benchmark('optimized.onnx')
    print(f'Original:  {a:.3f} ms')
    print(f'Optimized: {b:.3f} ms')
    print(f'Speedup:   {a / b:.2f}x')
    print('CPU latency is not RK3566 NPU latency.')

# Lab 1 — Find and optimize an expensive convolution in Netron

**Level:** beginner/intermediate · **Tools:** PyTorch, ONNX, Netron, ONNX Runtime · **Hardware:** CPU only for this lab; RK3566 optional later

> **Learning outcome:** By the end you will be able to read a CNN computation graph, explain each operator, calculate parameters and multiply–accumulate operations (MACs), replace one expensive convolution, and test whether it actually speeds up inference.

![Original versus optimized network](assets/architecture.svg)

## 0. Before starting — the mental model

A neural network is a **directed graph**: each node (operator) reads one or more **tensors** and produces new tensors. **Netron shows that graph**. It does not execute it or measure NPU latency.

The notation **`[N, C, H, W]`** means:

| Symbol | Meaning | Example |
|---|---|---|
| `N` | Batch size (images processed together) | `1` |
| `C` | Channels (feature maps) | `32` |
| `H` | Feature-map height | `112` |
| `W` | Feature-map width | `112` |

An RGB image of `[1,3,224,224]` becomes 32 learned feature maps after the first convolution. The feature maps aren't 32 color images; each represents a learned pattern response.

### Operator cheat sheet

| Operator | What it does | Changes tensor shape? | Look for in Netron |
|---|---|---|---|
| `Conv` | Uses learned kernels to extract spatial patterns and/or mix channels | Often | `kernel_shape`, `strides`, `pads`, `group`, weights |
| `Relu` | Replaces negative values with zero: `max(0, x)` | No | Input/output shape |
| `GlobalAveragePool` | Averages every `H×W` map into one number per channel | Yes, spatial dims → `1×1` | Input/output shape |
| `Flatten` | Turns `[N,C,1,1]` into `[N,C]` | Yes, reshapes | `axis` |
| `Gemm` | Matrix multiplication plus optional bias (the `Linear` layer) | Yes | Weights and `transB` |

A **kernel** is a small grid of weights, e.g., 3×3. A **stride** of 2 moves the kernel two pixels at a time and generally downsamples the feature map. **Padding** adds border values, often zeros, to preserve dimensions. **Groups** controls which input channels connect to each output channel.

---

## 1. Setup

Open a terminal in the `code/` folder:

```bash
cd code
python -m pip install -r requirements.txt
```

If your current PyTorch setup is already installed, you can install only missing packages. PyTorch CPU/GPU wheels depend on your platform; use the official PyTorch installation guidance if needed.

**Checkpoint:** `python -c "import torch, onnx, onnxruntime, netron; print('ready')"` prints `ready`.

## 2. Generate the original and optimized models

Run:

```bash
python network.py
```

This creates `original.onnx` and `optimized.onnx` in `code/`. You do **not** need a trained model to inspect layer structure.

The core of the **original** model is:

```python
nn.Conv2d(32, 64, kernel_size=3, padding=1)
```

It takes 32 input feature maps and produces 64 output feature maps, at the same spatial resolution.

The optimized replacement is:

```python
nn.Sequential(
    nn.Conv2d(32, 32, kernel_size=3, padding=1,
              groups=32, bias=False),
    nn.Conv2d(32, 64, kernel_size=1),
)
```

We keep the **input and output tensor shapes identical**, so the rest of the network can stay unchanged.

**Expected parameter counts (entire model, including biases):**

| Model | Parameters |
|---|---:|
| Original | **20,042** |
| Optimized | **3,946** |

**Checkpoint:** Both models output `[1,10]` logits. These logits are arbitrary because the weights are randomly initialized: **do not compare classification accuracy yet**.

## 3. Open the original model in Netron

```bash
netron original.onnx
```

Netron typically starts a local server and opens the browser. You can also open the `.onnx` file at <https://netron.app> if you are comfortable uploading the model to that service.

### What you should see

```text
input [1,3,224,224]
   │
   ▼
Conv 3×3 / stride 2       ← stem: 3 → 32 channels
   │ [1,32,112,112]
   ▼
Relu
   │
   ▼
Conv 3×3 / stride 1       ← TARGET: 32 → 64 channels
   │ [1,64,112,112]
   ▼
Relu
   ▼
GlobalAveragePool
   │ [1,64,1,1]
   ▼
Flatten
   │ [1,64]
   ▼
Gemm (Linear)
   │ [1,10]
   ▼
logits
```

> Depending on exporter version, Netron may display additional initializer nodes or slightly different labels, but the same logical operations should be present.

### Click the **second `Conv`** (the target)

Find the following attributes or their equivalent names:

| Property | Expected value | Interpretation |
|---|---|---|
| Input shape | `[1,32,112,112]` | 32 feature maps |
| Output shape | `[1,64,112,112]` | 64 resulting maps |
| `kernel_shape` | `[3,3]` | Each filter looks at a 3×3 neighborhood |
| `strides` | `[1,1]` | Move by 1 pixel per application |
| `pads` | `[1,1,1,1]` | One pixel of border padding |
| `group` | `1` | Standard dense convolution |
| Weight shape | `[64,32,3,3]` | One 32×3×3 filter bank per output channel |

**Mini-exercise:** Why doesn't this layer reduce 112×112 to 110×110? Because `padding=1` adds a one-pixel border around the input before applying the 3×3 kernel.

General output-size formula (per spatial dimension):

\[
O=\left\lfloor\frac{I+2P-D(K-1)-1}{S}+1\right\rfloor
\]

Here `I=112`, `P=1`, dilation `D=1`, kernel `K=3`, stride `S=1`, so `O=112`.

## 4. Understand the expensive operator

![How standard and depthwise-separable convolution process channels](assets/operators.svg)

### A. Standard convolution

A standard 3×3 convolution learns **one 3×3 kernel for every input-channel/output-channel pair**. For 32 input and 64 output channels, this is `32 × 64 × 9` values.

**Weights (no bias):**

\[
32\times 64\times 3\times 3=\boxed{18,432}
\]

**MACs:** one multiply–accumulate per weight at each of the `112 × 112` output positions:

\[
112\times112\times32\times64\times3\times3=\boxed{231,211,008}\ \text{MACs}
\]

A **MAC** is conventionally one multiplication and one addition. MAC counting is not the same as measuring runtime. Some tools report two FLOPs per MAC; definitions vary.

### B. Depthwise convolution

Set `groups=32` with 32 input and 32 output channels. Now each input channel is filtered **independently** by one 3×3 kernel. It learns spatial patterns but does **not** mix different channels.

- Weight tensor: `[32,1,3,3]`
- Weights: `32 × 1 × 9 = 288`
- MACs: `112 × 112 × 288 = 3,612,672`

### C. Pointwise convolution

A **1×1 convolution** combines information across channels at every pixel location. It provides channel mixing after the depthwise filter.

- Weight tensor: `[64,32,1,1]`
- Weights: `64 × 32 = 2,048`
- MACs: `112 × 112 × 2,048 = 25,690,112`

### D. Compare the target layer

| Metric | Standard 3×3 | Depthwise 3×3 + pointwise 1×1 |
|---|---:|---:|
| Weights (without bias) | 18,432 | 288 + 2,048 = **2,336** |
| MACs | **231.21M** | **29.30M** |
| Output shape | `[1,64,112,112]` | `[1,64,112,112]` |
| Reduction | — | **87.3% fewer target-layer MACs** |

**Important:** This is not an algebraically identical substitution for arbitrary original weights. The replacement has fewer learned parameters and may lose accuracy. It must be trained or fine-tuned before any accuracy comparison.

## 5. Inspect the optimized model in Netron

Open a second terminal or replace the first Netron page:

```bash
netron optimized.onnx
```

In the original graph, the target is **one `Conv`**. In the optimized graph, find **two `Conv` nodes**:

```text
[1,32,112,112]
      │
      ▼
Depthwise Conv 3×3
 group = 32
 weights = [32,1,3,3]
      │
      ▼
[1,32,112,112]
      │
      ▼
Pointwise Conv 1×1
 group = 1
 weights = [64,32,1,1]
      │
      ▼
[1,64,112,112]
```

**Netron checklist:**

- [ ] The first optimized `Conv` has `group=32`.
- [ ] Its weights have shape `[32,1,3,3]`.
- [ ] The next `Conv` has `kernel_shape=[1,1]`.
- [ ] Its weights have shape `[64,32,1,1]`.
- [ ] The final output is still `[1,10]`.

**Reflection:** More operators does **not** necessarily mean more computation. The replacement uses two convolutions but ~8× fewer target-layer MACs.

## 6. Benchmark actual CPU inference

From the `code/` folder:

```bash
python benchmark.py
```

The script runs each ONNX model in ONNX Runtime, warms up the CPU, measures 100 inferences, and reports the **median latency**:

```text
Original:  ... ms
Optimized: ... ms
Speedup:   ... x
```

Do not copy a made-up latency into your results. Use values produced on your machine.

**Why won't 87% fewer MACs necessarily mean 87% less latency?** The CPU runtime may use different kernels; operator launch overhead, cache/memory bandwidth, threading, and the unchanged layers all affect total time.

**Fair-comparison rules:** same machine, same input shape, same runtime provider, same number of threads, warmup before timing, multiple repetitions. The benchmark uses **one CPU thread** for reproducibility, not maximum throughput.

## 7. Fill out your lab worksheet

| Question / Metric | Original | Optimized |
|---|---:|---:|
| Target Conv count | 1 | 2 |
| Target weight count (no bias) | 18,432 | 2,336 |
| Target MACs | 231.21M | 29.30M |
| Entire model parameters | 20,042 | 3,946 |
| Output shape | `[1,10]` | `[1,10]` |
| CPU median latency (ms) | *measure* | *measure* |
| CPU speedup | — | *calculate* |
| Validation accuracy | **not measured** | **not measured** |

Write your conclusion in three sentences:

1. **Observation in Netron:** Which operators and attributes changed?
2. **Theoretical gain:** How much did target-layer MAC count decrease?
3. **Measured gain:** Did CPU latency decrease? If not, why might that be?

## 8. Extra challenge: Find the next layer worth optimizing

Click the **first** convolution (the stem). It has input `[1,3,224,224]`, output `[1,32,112,112]`, a 3×3 kernel, and stride 2.

Calculate its MACs:

\[
112\times112\times3\times32\times9=10,838,016
\]

Compare that against the **231.2M MACs** of the original target layer. Which layer had the larger theoretical cost, and why? Hint: both process outputs of spatial size 112×112, but the channel counts are very different.

## 9. Optional extension — RK3566 NPU

After completing the CPU experiment, export both ONNX files to RKNN with the same conversion settings, then profile on **real RK3566 hardware**. Keep quantization disabled for the first comparison, if supported by your installed toolkit/runtime configuration. Repeat with a representative INT8 calibration dataset in a later lab.

**Do not interpret simulator execution time as NPU latency.** Use the RKNN profiler/runtime on the board to check end-to-end latency and operator timing. Also check operator support and any CPU fallback behavior using the target-specific tooling.

## 10. Troubleshooting

| Problem | Suggested action |
|---|---|
| `ModuleNotFoundError: onnx` | Run `python -m pip install onnx` in the same environment. |
| `torch.onnx.export` complains about missing dependencies | Install `onnx`; ensure PyTorch and ONNX versions are compatible. |
| Netron shows unfamiliar operator names | Check tensor shapes, `group`, `kernel_shape`, and weights rather than relying only on labels. |
| No speedup on CPU | This can be normal; retest under consistent conditions and profile on target hardware. |
| Optimized model gives different predictions | Expected! The two models use independent random weights and are not functionally identical. |

### Done when

You can explain **standard convolution**, **depthwise convolution**, **pointwise convolution**, **ReLU**, **global average pooling**, and **linear/Gemm**; point to each in Netron; and give a measured CPU speedup without confusing theoretical MAC savings with actual NPU performance.

---

**Files:** `code/network.py` builds both ONNX models; `code/benchmark.py` runs the CPU comparison; `assets/` contains the illustrations. Run commands from within `code/` unless otherwise indicated.

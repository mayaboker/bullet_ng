"""Compare ONNX CPU latency. Run in the code directory after network.py."""
import time
import numpy as np
import onnxruntime as ort


def median_ms(filename, runs=100):
    options = ort.SessionOptions()
    options.intra_op_num_threads = 1
    session = ort.InferenceSession(filename, sess_options=options,
                                   providers=["CPUExecutionProvider"])
    input_name = session.get_inputs()[0].name
    array = np.random.default_rng(42).normal(size=(1, 3, 224, 224)).astype("float32")
    for _ in range(20):
        session.run(None, {input_name: array})
    elapsed = []
    for _ in range(runs):
        t0 = time.perf_counter()
        result = session.run(None, {input_name: array})
        assert result[0].shape == (1, 10)
        elapsed.append((time.perf_counter() - t0) * 1000)
    return float(np.median(elapsed))


if __name__ == "__main__":
    baseline = median_ms("baseline.onnx")
    narrow = median_ms("narrow.onnx")
    print(f"Baseline: {baseline:.3f} ms")
    print(f"Narrow:   {narrow:.3f} ms")
    print(f"Speedup:  {baseline / narrow:.2f}x")
    print("Reminder: CPU runtime is not a predictor of RK3566 NPU latency.")

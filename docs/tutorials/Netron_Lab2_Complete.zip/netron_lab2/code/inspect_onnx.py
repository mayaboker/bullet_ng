"""Print Conv shapes/attributes in both exported ONNX graphs."""
import onnx
from onnx import helper, shape_inference


def summarize(filename):
    model = shape_inference.infer_shapes(onnx.load(filename))
    shapes = {}
    for value in list(model.graph.input) + list(model.graph.value_info) + list(model.graph.output):
        shapes[value.name] = [d.dim_value or d.dim_param or "?" for d in value.type.tensor_type.shape.dim]
    weights = {w.name: list(w.dims) for w in model.graph.initializer}
    print(f"\n{filename}")
    for node in model.graph.node:
        if node.op_type not in ("Conv", "Relu", "GlobalAveragePool", "Flatten", "Gemm"):
            continue
        attrs = {attr.name: helper.get_attribute_value(attr) for attr in node.attribute}
        w = weights.get(node.input[1]) if len(node.input) > 1 else None
        inp = shapes.get(node.input[0], "?")
        out = shapes.get(node.output[0], "?")
        print(f"{node.op_type:18} input={inp} output={out} weights={w} "
              f"group={attrs.get('group', 1) if node.op_type == 'Conv' else '-'}")


if __name__ == "__main__":
    summarize("baseline.onnx")
    summarize("narrow.onnx")

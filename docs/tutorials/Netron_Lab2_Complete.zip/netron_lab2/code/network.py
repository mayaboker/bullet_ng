"""Lab 2: halve a standard convolution's output channels (64 -> 32)."""
from pathlib import Path
import torch
from torch import nn


class ChannelCNN(nn.Module):
    def __init__(self, feature_channels: int = 64):
        super().__init__()
        self.stem = nn.Sequential(
            nn.Conv2d(3, 32, kernel_size=3, stride=2, padding=1),
            nn.ReLU(),
        )
        self.feature = nn.Conv2d(32, feature_channels, kernel_size=3, padding=1)
        self.relu = nn.ReLU()
        self.pool = nn.AdaptiveAvgPool2d(1)
        # Must follow feature_channels: narrowing Conv also narrows classifier input.
        self.classifier = nn.Linear(feature_channels, 10)

    def forward(self, x):
        x = self.stem(x)
        x = self.relu(self.feature(x))
        x = self.pool(x)
        x = torch.flatten(x, 1)
        return self.classifier(x)


def export_model(model: nn.Module, destination: Path):
    model.eval()
    x = torch.randn(1, 3, 224, 224)
    with torch.no_grad():
        assert tuple(model(x).shape) == (1, 10)
    torch.onnx.export(
        model, (x,), str(destination),
        input_names=["input"], output_names=["logits"],
        opset_version=17, dynamo=False,
    )


if __name__ == "__main__":
    torch.manual_seed(42)
    for label, width in [("baseline", 64), ("narrow", 32)]:
        model = ChannelCNN(feature_channels=width)
        export_model(model, Path(f"{label}.onnx"))
        params = sum(p.numel() for p in model.parameters())
        print(f"{label}: width={width}, parameters={params:,}, output=(1, 10)")

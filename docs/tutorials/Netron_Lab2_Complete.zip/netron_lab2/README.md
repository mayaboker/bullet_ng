# Lab 2 — Optimize CNN channel width using Netron

**Level:** beginner/intermediate · **Time:** self-paced · **Tools:** PyTorch, ONNX, Netron, ONNX Runtime · **Hardware:** desktop CPU; RK3566 optional

**Mission:** Starting with the Lab 1-style CNN, change one expensive convolution from **64 output channels to 32**, update its downstream classifier, and measure the effects on tensors, weights, MACs and CPU inference latency.

![Original and narrower CNNs](assets/architecture.svg)

> **Main idea:** A convolution's channel count is a design choice. Fewer output channels means fewer feature maps, fewer filters, and usually fewer MACs—but possibly worse model accuracy. Netron helps you see the structural effects; benchmarking and validation tell you whether the change is beneficial.

## 0. What you should know first

Each tensor in the lab uses **NCHW** layout: `[batch, channels, height, width]`. Example: `[1,32,112,112]` is one image represented by 32 feature maps, each 112×112.

| Operator | Meaning | What changes? |
|---|---|---|
| `Conv` | Applies learnable spatial filters and combines input channels | Spatial size and/or channel count |
| `Relu` | Applies `max(0,x)` to each value | Values, not shape |
| `GlobalAveragePool` | Averages each spatial feature map into one number | `[N,C,H,W]` → `[N,C,1,1]` |
| `Flatten` | Reshapes features into a vector | `[N,C,1,1]` → `[N,C]` |
| `Gemm` / `Linear` | Projects the feature vector to class scores | `[N,C]` → `[N,10]` |

**Channel width versus spatial size:** Reducing channels `64→32` does **not** change the spatial resolution `112×112`. By contrast, changing stride often reduces H and W.

![Channel maps illustration](assets/channels.svg)

## 1. Install the tools

Open a terminal inside `netron_lab2/code/`:

```bash
cd netron_lab2/code
python -m pip install -r requirements.txt
python -c "import torch, onnx, onnxruntime, netron; print('ready')"
```

Use an existing PyTorch installation if you already have one; the correct PyTorch wheel depends on your machine.

**Checkpoint:** Python prints `ready`.

## 2. Read the baseline PyTorch network

Open `code/network.py`. The important lines are:

```python
self.stem = nn.Sequential(
    nn.Conv2d(3, 32, kernel_size=3, stride=2, padding=1),
    nn.ReLU(),
)
self.feature = nn.Conv2d(32, feature_channels, kernel_size=3, padding=1)
self.relu = nn.ReLU()
self.pool = nn.AdaptiveAvgPool2d(1)
self.classifier = nn.Linear(feature_channels, 10)
```

The original setting is `feature_channels=64`:

```text
Input           [1, 3, 224, 224]
   │
   ▼
Conv 3×3, s=2   3 → 32
   │            [1, 32, 112, 112]
   ▼
ReLU            [1, 32, 112, 112]
   ▼
Conv 3×3, s=1   32 → 64         ← THE TARGET
   │            [1, 64, 112, 112]
   ▼
ReLU            [1, 64, 112, 112]
   ▼
GlobalAvgPool   [1, 64, 1, 1]
   ▼
Flatten         [1, 64]
   ▼
Linear          64 → 10
   │
   ▼
Logits          [1, 10]
```

### Understand each operator

**First Conv (stem):** `3→32`, kernel 3×3, stride 2, padding 1. For each output channel it learns 3 input-channel kernels; because stride is 2, 224×224 becomes 112×112.

**First ReLU:** removes negative activations, providing nonlinearity. It doesn't change tensor shape.

**Second Conv (target):** `32→64`, kernel 3×3, stride 1, padding 1. Each of the 64 output maps mixes information from all 32 input maps. Every output map has a distinct bank of 32 kernels.

**Second ReLU:** again keeps positive values and zeros out negatives.

**GlobalAveragePool:** one spatial average per feature map; 64 maps become 64 scalars.

**Flatten:** reshapes the `[1,64,1,1]` tensor into `[1,64]` without changing its values.

**Linear:** multiplies the 64 features by a 10×64 weight matrix (plus biases), producing 10 class logits. These are unnormalized class scores, not probabilities.

## 3. Generate both ONNX networks

From `code/`, run:

```bash
python network.py
```

Expected output:

```text
baseline: width=64, parameters=20,042, output=(1, 10)
narrow: width=32, parameters=10,474, output=(1, 10)
```

You get `baseline.onnx` and `narrow.onnx`.

**Why do we change the classifier too?** After pooling, the narrow model produces 32 features rather than 64. `Linear(64,10)` would reject a 32-feature tensor. We must use `Linear(32,10)` instead. The network's **external interface stays `[1,10]`**, but internal feature shapes change.

**Checkpoint:** Both models export successfully; there is no training in this lab, so predictions are arbitrary.

## 4. Open the baseline graph in Netron

```bash
netron baseline.onnx
```

Select the **second `Conv`** operator. In its details pane, locate:

| Netron property | Expected | Explanation |
|---|---|---|
| Input shape | `[1,32,112,112]` | Number of incoming feature maps = 32 |
| Output shape | `[1,64,112,112]` | Number of produced maps = 64 |
| `kernel_shape` | `[3,3]` | Spatial window of each kernel |
| `strides` | `[1,1]` | One step between output positions |
| `pads` | `[1,1,1,1]` | Maintains 112×112 resolution |
| `group` | 1 (possibly omitted) | Every output channel sees every input channel |
| Weight tensor | `[64,32,3,3]` | 64 filter banks × 32 inputs × 9 weights |

**Netron task:** Click the weight initializer associated with the Conv node. Find its dimensions; they are as important as the operator attributes.

Optional independent ONNX inspection:

```bash
python inspect_onnx.py
```

This prints relevant operator input/output shapes and convolution weight dimensions. Some exporter versions may change names or insert additional nodes.

### Checkpoint questions

1. Why does output `H×W` stay 112×112? (Stride 1 and padding 1.)
2. Does `group=1` mean one filter? (No; it means standard channel connectivity.)
3. How do you know there are 64 output maps? (The first dimension of the weight tensor; or the output tensor's channel dimension.)

## 5. Calculate the baseline cost by hand

A standard convolution has learnable **weights**:

\[
W = C_{out}\times C_{in}\times K_h\times K_w
\]

Our target Conv has:

\[
W_{64}=64\times32\times3\times3=\boxed{18,432\ \text{weights}}
\]

It has one **bias per output channel** by default, so its **total trainable parameters** are `18,432+64=18,496`.

For batch size 1, convolution MACs are:

\[
MACs = H_{out}\times W_{out}\times C_{out}\times (C_{in}/groups)\times K_h\times K_w
\]

With `group=1`:

\[
MACs_{64}=112\times112\times64\times32\times9
=\boxed{231,211,008\ \text{MACs}}
\]

A MAC is a multiply-accumulate operation. Some profiler tools count one MAC as two FLOPs; ensure you compare like-for-like.

**Hands-on:** Independently calculate the target Conv weights and MACs before reading the next section.

## 6. Make the change: 64 output channels → 32

The only architectural setting that needs changing is `feature_channels`:

```python
baseline = ChannelCNN(feature_channels=64)
narrow   = ChannelCNN(feature_channels=32)
```

The Python class automatically changes both:

```python
self.feature = nn.Conv2d(32, 32, kernel_size=3, padding=1)
self.classifier = nn.Linear(32, 10)
```

Why this works: the output of the Conv is now `[1,32,112,112]`; after pooling/flattening it's `[1,32]`; `Linear(32,10)` produces `[1,10]` logits.

**This is not an exactly equivalent transformation.** The new model has fewer learned feature maps and may lose discriminative information. There is no guarantee its randomly initialized predictions resemble the baseline's, and any accuracy comparison requires training/evaluation.

## 7. Open and inspect the narrow model

```bash
netron narrow.onnx
```

Click the second `Conv` again and compare:

| Property | Baseline | Narrow |
|---|---|---|
| Input | `[1,32,112,112]` | `[1,32,112,112]` |
| Output | `[1,64,112,112]` | `[1,32,112,112]` |
| Kernel | 3×3 | 3×3 |
| Stride | 1 | 1 |
| Groups | 1 | 1 |
| Weights | `[64,32,3,3]` | `[32,32,3,3]` |
| Pool output | `[1,64,1,1]` | `[1,32,1,1]` |
| Linear input | 64 | 32 |
| Final output | `[1,10]` | `[1,10]` |

**Checkpoint:** Explain why the last layer must be modified even though its output remains 10.

## 8. Calculate the savings

For the narrow Conv:

\[
W_{32}=32\times32\times3\times3=\boxed{9,216\ \text{weights}}
\]

Plus 32 biases = **9,248 parameters**.

\[
MACs_{32}=112\times112\times32\times32\times9
=\boxed{115,605,504\ \text{MACs}}
\]

![MACs before and after width reduction](assets/cost.svg)

| Metric | Baseline | Narrow | Reduction |
|---|---:|---:|---:|
| Target Conv weights (without bias) | 18,432 | 9,216 | 50% |
| Target Conv parameters (with bias) | 18,496 | 9,248 | 50% |
| Target Conv MACs | 231.2M | 115.6M | 50% |
| Whole-model parameters | 20,042 | 10,474 | 47.7% |
| Whole-model MACs¹ | 242.05M | 126.44M | 47.8% |
| Target output elements | 802,816 | 401,408 | 50% |
| Target output FP32 storage² | 3.06 MiB | 1.53 MiB | 50% |

¹ Counting Conv and Linear MACs at batch size 1, excluding ReLU, pooling, and memory movement. ² Just one output tensor, not total peak RAM; assumes FP32 with 4 bytes per element. Real buffers and operator fusion vary.

**Key distinction:** Reducing only `C_out` by half reduces **this layer's** weights and MACs by half. It also reduces the next layer's input width. It does *not* make the total inference latency exactly twice as fast.

## 9. Benchmark both ONNX graphs on CPU

From `code/`:

```bash
python benchmark.py
```

The script runs 20 warmup passes and measures the median latency of 100 inference calls using ONNX Runtime's CPU provider (single-threaded intra-op).

Fill in this worksheet using **your** measurements:

| Result | Value |
|---|---|
| Baseline CPU latency (ms) | ______ |
| Narrow CPU latency (ms) | ______ |
| Speedup (`baseline/narrow`) | ______ |
| Did a ~47.8% MAC reduction create a ~1.91× speedup? | ______ |

**Why may real speedup differ?** Kernel dispatch, memory bandwidth, vectorization, cache behavior, different operator implementations, and the percentage of runtime spent in non-convolution operators. MACs express arithmetic workload; they don't directly measure wall-clock time.

**For NPU measurements:** Convert both models to RKNN with the same Toolkit2 version, target platform, quantization settings and input shape; then evaluate actual hardware performance. PC ONNX CPU timing is not an RK3566 latency prediction. For an initial architectural comparison, keep quantization disabled; later repeat under the same INT8 calibration/evaluation protocol.

## 10. Mini-challenge: experiment with 16, 32, 64, 96 channels

Edit the model generation loop in `network.py` or run in a small Python snippet. Suggested widths: `16`, `32`, `64`, `96`.

For each width, predict and then verify:

- Target Conv weight tensor shape (`[width,32,3,3]`).
- Target Conv MACs (`112×112×width×32×9`).
- Pool output and classifier input dimensions.
- Whole-model parameter count and CPU latency.

Sample exercise table (fill it yourself):

| Width | Conv weights | Target MACs | CPU latency |
|---:|---:|---:|---:|
| 16 | ______ | ______ | ______ |
| 32 | 9,216 | 115.6M | ______ |
| 64 | 18,432 | 231.2M | ______ |
| 96 | ______ | ______ | ______ |

### Reflection questions

1. Does halving **output channels** also halve *input* channels for the target Conv? **No**: its input stays at 32.
2. What if you reduce the **stem** from 32 to 16 channels? The next Conv's input channels must also change; now multiple layers are affected.
3. Why can't Netron tell you whether the new network is more accurate? It doesn't evaluate labeled data.
4. Why is this different from Lab 1? Lab 1 swapped one dense Conv for depthwise + pointwise operations while preserving its channel interface. Lab 2 changes the width of an intermediate representation and consequently changes downstream layers.

## 11. Optional RK3566 extension

1. Export `baseline.onnx` and `narrow.onnx` (already done).
2. Convert each using RKNN-Toolkit2 with `target_platform='rk3566'`, identical conversion settings, and compatible runtime/toolkit versions.
3. Run both on the same RK3566 device with matching input, warmup, and repeated measurements.
4. Compare total latency and, where supported, operator-level timings via RKNN profiling.
5. Only after a trained baseline exists, retrain or fine-tune the narrow architecture and compare validation accuracy.

**What Netron cannot show:** actual NPU operator scheduling, hidden compiler fusions, and precise per-layer execution time. Use hardware profiling for these.

## 12. Completion checklist

- [ ] I can explain `[N,C,H,W]` without confusing channels with spatial resolution.
- [ ] I located target Conv in Netron and read its weight tensor shape.
- [ ] I changed `C_out=64` to `C_out=32`.
- [ ] I updated `Linear(64,10)` to `Linear(32,10)`.
- [ ] I verified both models still output `[1,10]`.
- [ ] I calculated 50% fewer MACs in the target Conv.
- [ ] I measured CPU latency rather than assuming it matches MAC reduction.
- [ ] I understand that accuracy requires retraining and labeled evaluation.

**Next Lab:** compare 5×5 standard convolution with two stacked 3×3 convolutions, considering receptive field, parameters, nonlinearities and hardware behavior.

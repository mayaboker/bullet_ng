"""Print ONNX Conv operators, shapes, parameters and MAC estimates."""
import argparse
import math
import onnx
from onnx import shape_inference


def shape_map(graph):
    result = {}
    for vi in list(graph.input) + list(graph.value_info) + list(graph.output):
        dims = vi.type.tensor_type.shape.dim
        result[vi.name] = [d.dim_value if d.HasField('dim_value') else '?' for d in dims]
    for init in graph.initializer:
        result[init.name] = list(init.dims)
    return result


def report(path):
    model = shape_inference.infer_shapes(onnx.load(path))
    graph = model.graph
    shapes = shape_map(graph)
    weights = {w.name: w for w in graph.initializer}
    print(f'\nMODEL: {path}')
    total_macs = 0
    for node in graph.node:
        if node.op_type != 'Conv':
            continue
        in_shape = shapes.get(node.input[0], [])
        out_shape = shapes.get(node.output[0], [])
        weight = weights.get(node.input[1])
        if weight is None:
            print('Conv with nonconstant weights:', node.name)
            continue
        attrs = {a.name: onnx.helper.get_attribute_value(a) for a in node.attribute}
        group = attrs.get('group', 1)
        w_shape = list(weight.dims)  # [Cout, Cin/group, kH, kW]
        weight_params = math.prod(w_shape)
        bias_params = math.prod(weights[node.input[2]].dims) if len(node.input) > 2 and node.input[2] in weights else 0
        macs = (math.prod(out_shape[2:]) * w_shape[0] * math.prod(w_shape[1:])) if all(isinstance(x, int) and x > 0 for x in out_shape) else 0
        total_macs += macs
        print(f'  Conv {in_shape} -> {out_shape}, kernel={w_shape[2:]}, '
              f'groups={group}, weights={weight_params:,}, biases={bias_params:,}, MACs={macs:,}')
    print(f'  Conv-only total MACs: {total_macs:,}')


if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('models', nargs='*', default=['baseline.onnx', 'optimized.onnx'])
    for filename in p.parse_args().models:
        report(filename)

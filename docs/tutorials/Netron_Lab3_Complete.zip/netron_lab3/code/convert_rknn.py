"""Optional: run on x86 Linux with a compatible RKNN-Toolkit2 installation."""
from rknn.api import RKNN

for name in ('baseline', 'optimized'):
    rknn = RKNN(verbose=True)
    try:
        assert rknn.config(target_platform='rk3566') == 0
        assert rknn.load_onnx(model=f'{name}.onnx') == 0
        assert rknn.build(do_quantization=False) == 0
        assert rknn.export_rknn(f'{name}.rknn') == 0
        print('Exported:', f'{name}.rknn')
    finally:
        rknn.release()

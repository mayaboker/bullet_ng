"""Lab 3: one 5x5 convolution vs two 3x3 convolutions."""
import argparse
import torch
from torch import nn


class LabCNN(nn.Module):
    def __init__(self, variant='baseline'):
        super().__init__()
        if variant not in ('baseline', 'optimized'):
            raise ValueError(f'Unknown variant: {variant}')
        self.stem = nn.Sequential(
            nn.Conv2d(3, 32, kernel_size=3, stride=2, padding=1),
            nn.ReLU(),
        )
        if variant == 'baseline':
            self.feature = nn.Sequential(
                nn.Conv2d(32, 64, kernel_size=5, stride=1, padding=2),
                nn.ReLU(),
            )
        else:
            self.feature = nn.Sequential(
                nn.Conv2d(32, 32, kernel_size=3, stride=1, padding=1),
                nn.ReLU(),
                nn.Conv2d(32, 64, kernel_size=3, stride=1, padding=1),
                nn.ReLU(),
            )
        self.pool = nn.AdaptiveAvgPool2d((1, 1))
        self.classifier = nn.Linear(64, 10)

    def forward(self, x):
        x = self.stem(x)
        x = self.feature(x)
        x = self.pool(x)
        x = x.flatten(1)
        return self.classifier(x)


def export_model(variant, filename):
    model = LabCNN(variant).eval()
    dummy = torch.randn(1, 3, 224, 224)
    with torch.no_grad():
        output = model(dummy)
    assert tuple(output.shape) == (1, 10)
    torch.onnx.export(
        model, (dummy,), filename,
        opset_version=17,
        input_names=['input'], output_names=['logits'],
        dynamo=False,
    )
    parameters = sum(p.numel() for p in model.parameters())
    print(f'{variant:9s} -> {filename}: params={parameters:,}, output={tuple(output.shape)}')


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--variant', choices=['baseline', 'optimized', 'both'], default='both')
    args = parser.parse_args()
    variants = ('baseline', 'optimized') if args.variant == 'both' else (args.variant,)
    for variant in variants:
        export_model(variant, f'{variant}.onnx')

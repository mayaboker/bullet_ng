"""Measure CPU ONNX Runtime latency (not RK3566/NPU latency)."""
import argparse
import statistics
import time
import numpy as np
import onnxruntime as ort


def benchmark(path, runs, warmup):
    options = ort.SessionOptions()
    options.intra_op_num_threads = 1
    options.inter_op_num_threads = 1
    session = ort.InferenceSession(
        path, sess_options=options, providers=['CPUExecutionProvider']
    )
    rng = np.random.default_rng(42)
    x = rng.standard_normal((1, 3, 224, 224)).astype(np.float32)
    input_name = session.get_inputs()[0].name
    for _ in range(warmup):
        session.run(None, {input_name: x})
    times = []
    for _ in range(runs):
        t0 = time.perf_counter()
        session.run(None, {input_name: x})
        times.append((time.perf_counter() - t0) * 1000)
    return statistics.median(times)


if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('--runs', type=int, default=100)
    p.add_argument('--warmup', type=int, default=20)
    args = p.parse_args()
    baseline = benchmark('baseline.onnx', args.runs, args.warmup)
    optimized = benchmark('optimized.onnx', args.runs, args.warmup)
    print(f'Baseline:  {baseline:.3f} ms')
    print(f'Optimized: {optimized:.3f} ms')
    print(f'Speedup:   {baseline / optimized:.2f}x')

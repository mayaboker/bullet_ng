# Netron Lab 3 — 5×5 vs Two 3×3 Convolutions

Open **[Lab3_Step_by_Step.md](Lab3_Step_by_Step.md)** for the full illustrated tutorial.

All commands are intended to run from `code/`. The files in `diagrams/` are local SVGs, so the Markdown works offline.

# Netron Hands-On — Lab 3
## Replace one 5×5 convolution with two 3×3 convolutions

**Level:** Beginner → intermediate  
**Duration:** 45–75 minutes  
**Tools:** Python, PyTorch, ONNX, Netron, ONNX Runtime; RKNN-Toolkit2 optional  
**Target hardware (optional):** Radxa Zero 3W / RK3566 NPU

> **Learning question:** Can two smaller spatial filters offer the same theoretical receptive-field size as one large filter, while using fewer computations?

![Baseline vs optimized networks](diagrams/01_architecture.svg)

## Learning objectives

By completing this lab, you should be able to:

1. Locate a convolution operator in Netron and read its **kernel, channel count, stride, padding, groups, and weight shape**.
2. Explain the difference between **kernel size** and **receptive field**.
3. Predict tensor dimensions after convolutions.
4. Calculate **weights, parameters (weights + biases), and MACs**.
5. Modify a model, export it to ONNX, inspect both graphs, and benchmark CPU inference.
6. Explain why fewer MACs do **not** guarantee an equal improvement in latency or preserved accuracy.

---

## Step 0 — Setup

From the extracted ZIP:

```bash
cd netron_lab3/code
python -m pip install -r requirements.txt
```

Use a Python environment compatible with the PyTorch and ONNX packages on your machine. Netron can also be opened via its web application if the CLI isn't available.

**Files in the lab:**

```text
netron_lab3/
├── Lab3_Step_by_Step.md
├── diagrams/
│   ├── 01_architecture.svg
│   ├── 02_receptive_field.svg
│   └── 03_cost_comparison.svg
└── code/
    ├── requirements.txt
    ├── models.py
    ├── inspect_onnx.py
    ├── benchmark.py
    └── convert_rknn.py      # Optional: RKNN-Toolkit2
```

**Checkpoint:** You can run `python -c "import torch, onnx, onnxruntime, netron; print('Ready')"` without errors.

---

## Step 1 — Understand the operators

Our network uses:

| Operator | What it does | Key properties to inspect in Netron |
|---|---|---|
| `Conv` | Learns spatial filters and mixes channels | `kernel_shape`, `strides`, `pads`, `group`, weights |
| `Relu` | Replaces negative activations with zero | Input/output shape; adds nonlinearity |
| `GlobalAveragePool` | Averages each channel across H×W | Output channels, spatial shape |
| `Flatten` | Reshapes a tensor to a vector | Axis and output shape |
| `Gemm` (or `MatMul`+`Add`) | Implements the final fully connected layer | Weight shape, output class count |

**Example:** A `Conv` with input `[1,32,112,112]`, weights `[64,32,5,5]`, `strides=[1,1]`, `pads=[2,2,2,2]`, `group=1` produces `[1,64,112,112]`.

Why? For one spatial dimension:

\[
H_{out}=\left\lfloor\frac{H_{in}+2P-K}{S}\right\rfloor+1
\]

Here: `(112 + 2×2 − 5)/1 + 1 = 112`.

**Try it:** Predict the output height if the stride becomes 2. **Answer:** 56.

---

## Step 2 — Understand a 5×5 filter

A single 5×5 convolution examines a 5×5 neighborhood for each output position. A 3×3 examines a smaller neighborhood. **Two 3×3 convolutions in sequence** allow the final output to depend on a 5×5 region, assuming stride 1 and dilation 1.

![5x5 receptive field comparison](diagrams/02_receptive_field.svg)

### Why is the effective receptive field 5×5?

- The first 3×3 convolution sees a 3×3 patch of the input.
- The second 3×3 convolution sees 3×3 positions from the **first layer's output**.
- Those first-layer positions jointly cover a 5×5 region of the original input.

Formula for two stride-1, dilation-1 layers:

\[
R=1+(3-1)+(3-1)=5.
\]

**Important nuance:** Equal theoretical receptive-field size does **not** mean the two implementations compute identical functions. The stacked version has an extra ReLU and a different weight factorization. It must be trained or fine-tuned for a meaningful accuracy comparison.

**Check your understanding:** What receptive-field size results from **three** consecutive 3×3 convolutions with stride 1? **Answer:** 7×7.

---

## Step 3 — Build both networks

Open [`code/models.py`](code/models.py). It implements both variants:

**Baseline target block:**

```python
nn.Conv2d(32, 64, kernel_size=5, stride=1, padding=2)
nn.ReLU()
```

**Optimized target block:**

```python
nn.Conv2d(32, 32, kernel_size=3, stride=1, padding=1)
nn.ReLU()
nn.Conv2d(32, 64, kernel_size=3, stride=1, padding=1)
nn.ReLU()
```

The rest of the network stays fixed:

```text
Input       [1, 3, 224, 224]
Stem        [1,32,112,112]   <- shared Conv3×3, stride=2
Target      [1,64,112,112]   <- one Conv5×5 OR two Conv3×3
GlobalPool  [1,64,1,1]
Flatten     [1,64]
Classifier  [1,10]
```

Note that the output shape remains the same even though the number of operators changes.

Run:

```bash
cd code
python models.py
```

This exports `baseline.onnx` and `optimized.onnx` and prints model parameter counts.

**Expected total parameters (including biases):**

- Baseline: **52,810**
- Optimized: **29,290**

**Checkpoint:** Both ONNX files exist and both models output `[1,10]`.

---

## Step 4 — Inspect `baseline.onnx` in Netron

```bash
netron baseline.onnx
```

Find the convolution after the stem's `Relu`. Click it and record:

| Property | Expected value |
|---|---|
| Type | `Conv` |
| Input | `[1,32,112,112]` |
| Output | `[1,64,112,112]` |
| Kernel | 5×5 |
| Weights | `[64,32,5,5]` |
| Stride | `[1,1]` |
| Padding | 2 on each side |
| Groups | 1 |

**Interpretation:** 64 output filters each combine data from 32 input channels, and each filter uses a 5×5 spatial kernel.

### Calculate the target block's weight count

\[
W=C_{out}\times C_{in}\times K\times K
=64\times32\times5\times5=51,200.
\]

Add 64 biases → **51,264 parameters** in the target convolution.

### Calculate the target block's MACs

\[
MACs=H_{out}\times W_{out}\times C_{out}\times C_{in}\times K^2
\]

\[
112\times112\times64\times32\times25
=\boxed{642,252,800\ MACs}.
\]

**Checkpoint:** You can explain why the target has 51,200 weights even though it processes 112×112 spatial positions: weights are **reused** at every output position.

---

## Step 5 — Inspect `optimized.onnx` in Netron

```bash
netron optimized.onnx
```

Locate **two consecutive `Conv` operators** in the target block.

| Property | First 3×3 | Second 3×3 |
|---|---:|---:|
| Input channels | 32 | 32 |
| Output channels | 32 | 64 |
| Input shape | `[1,32,112,112]` | `[1,32,112,112]` |
| Output shape | `[1,32,112,112]` | `[1,64,112,112]` |
| Weight shape | `[32,32,3,3]` | `[64,32,3,3]` |
| Weight count | 9,216 | 18,432 |
| Bias count | 32 | 64 |
| MACs | 115,605,504 | 231,211,008 |

The optimized target's total is:

- Weights: `9,216 + 18,432 = 27,648`.
- Parameters including biases: `27,648 + 32 + 64 = 27,744`.
- MACs: `115,605,504 + 231,211,008 = 346,816,512`.

**Visual comparison:**

![Target block MAC and parameter cost](diagrams/03_cost_comparison.svg)

**Checkpoint:** Which 3×3 convolution is more expensive? **Answer:** The second one, because it produces twice as many channels.

---

## Step 6 — Verify with an ONNX inspection script

Run from the `code` directory:

```bash
python inspect_onnx.py baseline.onnx optimized.onnx
```

This script reads the ONNX graph, infers tensor shapes, identifies `Conv` nodes, and calculates parameter and MAC counts based on their weight shapes.

Compare its numbers with the Netron attributes and your manual calculations.

**Expected target-block results:**

| Metric | One 5×5 | Two 3×3 | Reduction |
|---|---:|---:|---:|
| Weights | 51,200 | 27,648 | **46.0%** |
| MACs | 642.3M | 346.8M | **46.0%** |
| Target output tensor | `[1,64,112,112]` | `[1,64,112,112]` | 0% |
| Target Conv operator count | 1 | 2 | **+1** |

The **entire network** also includes a shared stem convolution and final classifier. Do not mistake target-layer reduction for whole-network latency reduction.

---

## Step 7 — Benchmark the two models on the CPU

Run:

```bash
python benchmark.py
```

The script performs a warmup, runs 100 iterations of both ONNX graphs, and reports **median inference latency** using ONNX Runtime's CPU provider, with one intra-op thread.

Fill in this table on your own machine:

| Metric | Baseline | Optimized |
|---|---:|---:|
| Target MACs | 642.3M | 346.8M |
| Model parameters | 52,810 | 29,290 |
| Measured median CPU latency (ms) | ______ | ______ |
| Measured speedup | — | ______ |

**Discussion:** Theoretical MACs exclude operator-launch overhead, memory access, cache effects, and framework-specific implementations. A graph with **two** operators may be slower than expected despite having fewer MACs.

**Important:** The models have *random, unrelated weights*. Their classification outputs should not be used to judge accuracy. Train/fine-tune both on the same dataset using the same split and recipe to compare validation accuracy.

---

## Step 8 — Optional RK3566 / RKNN extension

On a supported x86 Linux host with RKNN-Toolkit2 installed, run:

```bash
python convert_rknn.py
```

This converts the two ONNX models to `baseline.rknn` and `optimized.rknn` **without quantization**. Use the RKNN runtime or device-connected profiling on your actual RK3566 board to measure latency. Do not infer real NPU latency from ONNX Runtime or the RKNN simulator.

After the first architecture-only comparison, repeat with the **same** representative INT8 calibration dataset for each model. Inspect quantization errors and compare runtime again.

**Questions to answer:**

1. Does the RK3566 gain as much speed as the MAC reduction suggests?
2. Does adding an extra `Conv` and `ReLU` operator add meaningful overhead?
3. Does INT8 change the performance ranking?
4. Are any operators unsupported or executed differently on the target?

---

## Step 9 — Independent experiments

Try these changes, **one at a time**, and re-export to Netron after each modification:

| Experiment | Change | Prediction to test |
|---|---|---|
| A | Intermediate channels 32 → **16** | Lower target MACs and fewer parameters |
| B | Intermediate channels 32 → **64** | Higher target MACs and more parameters |
| C | Remove middle `ReLU` | Same Conv MACs but different representational power |
| D | Change first kernel 3×3 → **1×1** | Lower MACs but **3×3**, not 5×5, receptive field |
| E | Set dilation=2 for one 3×3 | Larger receptive field without extra kernel weights |

For experiment E, adjust padding to 2 if you want to preserve spatial shape, and compute the receptive field again.

### Answer key: experiment A

Two target convolutions: `32→16, 3×3` and `16→64, 3×3`.

- Weights: `32×16×9 + 16×64×9 = 13,824`.
- MACs: `112×112×13,824 = 173,408,256`.
- Effective receptive field remains 5×5.
- The intermediate channel bottleneck may reduce expressive capacity.

---

## Final exercise — Engineering decision

Write a short conclusion using this structure:

> **Hypothesis:** Replacing one 5×5 convolution with two 3×3 convolutions will reduce compute while retaining a 5×5 theoretical receptive field.  
> **Graph evidence:** The optimized model uses 346.8M rather than 642.3M MACs in the target block.  
> **CPU evidence:** [your measured latency].  
> **RK3566 evidence (optional):** [your profiled latency].  
> **Accuracy evidence (after training):** [validation accuracy and dataset].  
> **Decision:** [keep/reject the optimization, with reason].

### Takeaway

**Graph optimization involves a trade-off between mathematical capacity, theoretical workload, and hardware execution.** Netron lets you see and reason about the graph; benchmarks and validation data tell you whether the change is useful.

**Next lab:** Changing stride to reduce feature-map spatial resolution — and exploring why early downsampling can be very powerful but risks losing visual detail.
